﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string constr = ConfigurationManager.ConnectionStrings["mystr"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            InsertData();
        }

        private void InsertData()
        {
            try
            {
                SqlConnection cn = new SqlConnection(constr);
                cn.Open();
                SqlCommand cmd = new SqlCommand("insert into mytbl(studentname,address,country,state,city)values(@snm,@add,@country,@state,@city)", cn);
                cmd.Parameters.AddWithValue("@snm", txtname.Text);
                cmd.Parameters.AddWithValue("@add", txtadd.Text);
                cmd.Parameters.AddWithValue("@country", txtcountry.Text);
                cmd.Parameters.AddWithValue("@state", txtstate.Text);
                cmd.Parameters.AddWithValue("@city", txtcity.Text);
                cmd.ExecuteNonQuery();
                cn.Close();



            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }

        protected void btndlt_Click(object sender, EventArgs e)
        {
            DeleteData();
        }

        private void DeleteData()
        {
            try
            {
                SqlConnection cn = new SqlConnection(constr);
                cn.Open();
                SqlCommand cmd = new SqlCommand("delete from mytbl where id=@id", cn);

                cmd.Parameters.AddWithValue("@id", txtid.Text);
                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }

        protected void btnsrch_Click(object sender, EventArgs e)
        {
            FindData();
        }

        private void FindData()
        {
            try
            {
                SqlConnection cn = new SqlConnection(constr);
                cn.Open();
                SqlCommand cmd = new SqlCommand("select * from mytbl where id=@id", cn);
                cmd.Parameters.AddWithValue("@id", txtid.Text);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count >0)
                {
                    txtname.Text = dt.Rows[0]["studentname"].ToString();
                    txtadd.Text = dt.Rows[0]["address"].ToString();
                    txtcountry.Text = dt.Rows[0]["country"].ToString();
                    txtstate.Text = dt.Rows[0]["state"].ToString();
                    txtcity.Text = dt.Rows[0]["city"].ToString();
                }
                cn.Close();
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            Updatedata();
        }

        private void Updatedata()
        {
            try
            {
                SqlConnection cn = new SqlConnection(constr);
                cn.Open();
                SqlCommand cmd = new SqlCommand("update mytbl set studentname=@snm,address=@add,country=@country,state=@state,city=@city where id=@id", cn);
                cmd.Parameters.AddWithValue("@snm", txtname.Text);
                cmd.Parameters.AddWithValue("@add", txtadd.Text);
                cmd.Parameters.AddWithValue("@country", txtcountry.Text);
                cmd.Parameters.AddWithValue("@state", txtstate.Text);
                cmd.Parameters.AddWithValue("@city", txtcity.Text);
                cmd.Parameters.AddWithValue("@id", txtid.Text);
                cmd.ExecuteNonQuery();
                cn.Close();


            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }
    }
}